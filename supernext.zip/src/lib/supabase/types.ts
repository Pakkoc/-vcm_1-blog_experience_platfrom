export type Database = Record<string, never>;

export type SupabaseUserMetadata = Record<string, unknown>;
