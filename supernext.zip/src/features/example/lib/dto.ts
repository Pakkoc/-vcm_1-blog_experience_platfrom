export {
  ExampleParamsSchema,
  ExampleResponseSchema,
  type ExampleResponse,
} from '@/features/example/backend/schema';
